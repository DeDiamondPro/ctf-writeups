import os
import json
import time
import secrets
import hashlib
import sqlite3
from datetime import datetime, timedelta
from flask import Flask, render_template, request, session, redirect, url_for
from functools import wraps
from threading import Lock

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

FLAG = os.environ.get("FLAG", "CSC{example_flag_replace_me}")
DB_PATH = "/tmp/fortune_teller.db"
DB_LOCK = Lock()

LCG_A = 6364136223846793005
LCG_M = 2**64
LCG_C = 1442695040888963407

timestamp_ms = int(time.time() * 1000)
entropy = int.from_bytes(os.urandom(18), 'big')
lcg_seed = (timestamp_ms + entropy) % LCG_M

def init_db():
    """Initialize database with tables"""
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )''')
        
        c.execute('''CREATE TABLE IF NOT EXISTS fa_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            code TEXT NOT NULL,
            lcg_seed TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NOT NULL,
            verified INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )''')

        c.execute('''CREATE TABLE IF NOT EXISTS emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipient_email TEXT NOT NULL,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )''')
        
        admin_pass_hash = hash_password("moon_whisper_174")
        try:
            c.execute('''INSERT INTO users (username, password_hash, email)
                        VALUES (?, ?, ?)''',
                     ("seer", admin_pass_hash, "seer@ethereal.local"))
        except sqlite3.IntegrityError:
            pass
        
        webmail_pass_hash = hash_password("ancient_scroll_1337")
        try:
            c.execute('''INSERT INTO users (username, password_hash, email)
                        VALUES (?, ?, ?)''',
                     ("messenger", webmail_pass_hash, "messenger@ethereal.local"))
        except sqlite3.IntegrityError:
            pass
        
        conn.commit()
        conn.close()

def hash_password(password):
    """Hash password using SHA256"""
    return hashlib.sha256(password.encode()).hexdigest()

def get_user_by_username(username):
    """Fetch user from database"""
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
    return dict(user) if user else None

def get_user_by_id(user_id):
    """Fetch user from database by ID"""
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = c.fetchone()
        conn.close()
    return dict(user) if user else None

def get_user_by_email(email):
    """Fetch user from database by email"""
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE email = ?", (email,))
        user = c.fetchone()
        conn.close()
    return dict(user) if user else None

def create_user(username, password, email):
    """Create new user"""
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        password_hash = hash_password(password)
        try:
            c.execute('''INSERT INTO users (username, password_hash, email)
                        VALUES (?, ?, ?)''',
                     (username, password_hash, email))
            conn.commit()
            user_id = c.lastrowid
            conn.close()
            return user_id
        except sqlite3.IntegrityError:
            conn.close()
            return None

def lcg_next(seed):
    """LCG forward: X(n+1) = (a*X(n) + c) mod m, followed by XOR shifts"""
    x = (LCG_A * seed + LCG_C) % LCG_M
    MASK_64 = (1 << 64) - 1
    x = (x ^ (x << 21)) & MASK_64
    x = (x ^ (x >> 35)) & MASK_64
    x = (x ^ (x << 4)) & MASK_64
    return x

def generate_2fa_code(seed):
    """
    Generate a 20-digit 2FA code from a seed.
    """
    code_num = lcg_next(seed)
    code = str(code_num % 10**20).zfill(20)
    return code, code_num

def create_2fa_code(user_id, lcg_seed):
    """Create and store a new 2FA code"""
    code, code_num = generate_2fa_code(lcg_seed)
    expires_at = datetime.utcnow() + timedelta(minutes=15)

    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''INSERT INTO fa_codes (user_id, code, lcg_seed, expires_at)
                    VALUES (?, ?, ?, ?)''',
                 (user_id, code, str(lcg_seed), expires_at))
        conn.commit()
        conn.close()

    return code, code_num

def verify_2fa_code(user_id, code):
    """Verify 2FA code - only one attempt allowed"""
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()

        # Get the unverified 2FA code for this user
        c.execute('''SELECT * FROM fa_codes
                    WHERE user_id = ? AND verified = 0 AND expires_at > ?
                    ORDER BY created_at DESC LIMIT 1''',
                 (user_id, datetime.utcnow()))
        fa_code_record = c.fetchone()

        # If no unverified code exists, the user already used their attempt
        if not fa_code_record:
            conn.close()
            return False, "No valid 2FA code found. Please login again."

        # Mark the code as verified (used) regardless of whether it's correct
        c.execute('''UPDATE fa_codes SET verified = 1 WHERE id = ?''',
                 (fa_code_record[0],))
        conn.commit()

        # Check if the provided code matches
        if fa_code_record[2] == code:
            conn.close()
            return True, "Code verified!"
        else:
            conn.close()
            return False, "Invalid code. Please login again to get a new code."

def send_email(recipient_email, subject, body):
    """Store email in database (simulating sending)"""
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''INSERT INTO emails (recipient_email, subject, body)
                    VALUES (?, ?, ?)''',
                 (recipient_email, subject, body))
        conn.commit()
        conn.close()

def get_emails_for(email):
    """Get all emails for a specific email address"""
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute('''SELECT id, subject, body, sent_at FROM emails 
                    WHERE recipient_email = ? ORDER BY sent_at DESC''',
                 (email,))
        emails = [dict(row) for row in c.fetchall()]
        conn.close()
    return emails

def require_login(f):
    """Decorator for pages requiring login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def require_2fa_verified(f):
    """Decorator for pages requiring 2FA verification"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or 'verified_2fa' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ============ ROUTES ============

@app.route('/')
def index():
    """Homepage"""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    global lcg_seed
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        user = get_user_by_username(username)
        if not user or user['password_hash'] != hash_password(password):
            return render_template('login.html', error="Invalid credentials"), 401
        
        is_admin = (username == "seer")
        
        if is_admin:
            timestamp_ms = int(time.time() * 1000)
            entropy = int.from_bytes(os.urandom(18), 'big')
            lcg_seed = (timestamp_ms + entropy) % LCG_M
            code, lcg_seed = create_2fa_code(user['id'], lcg_seed)
        else:
            timestamp_ms = int(time.time() * 1000)
            entropy = int.from_bytes(os.urandom(18), 'big')
            code, lcg_seed = create_2fa_code(user['id'], lcg_seed)
            lcg_seed = (timestamp_ms + entropy) % LCG_M
            send_email(user['email'], 
                      "Your Sacred Code for Fortune Teller",
                      f"Your Sacred Code is: {code}\nThis code expires in 15 minutes.")
        
        session['user_id'] = user['id']
        session['pending_2fa'] = True
        
        return redirect(url_for('verify_2fa'))
    
    return render_template('login.html')

@app.route('/verify-2fa', methods=['GET', 'POST'])
def verify_2fa():
    """2FA verification"""
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        code = request.form.get('code', '').strip()

        user_id = session['user_id']
        success, message = verify_2fa_code(user_id, code)
        print(f'2FA: {message}')

        if success:
            session['verified_2fa'] = True
            session.pop('pending_2fa', None)
            return redirect(url_for('fortune'))
        else:
            # Clear session on failed attempt
            session.clear()
            # Display error and require login again
            return render_template('verify_2fa.html',
                                 error=message,
                                 failed=True)

    user = get_user_by_id(session['user_id'])
    return render_template('verify_2fa.html',
                          username=user['username'],
                          email=user['email'])

@app.route('/fortune')
@require_2fa_verified
def fortune():
    """Fortune page (requires 2FA)"""
    user = get_user_by_id(session['user_id'])
    
    if user['username'] == 'seer':
        fortune_text = f"🔮 Your Fortune: The flag is within reach... {FLAG}"
    else:
        fortune_text = "🔮 Your Fortune: Seek the hidden knowledge and you shall find your flag!"
    
    return render_template('fortune.html', 
                          username=user['username'],
                          fortune=fortune_text)

@app.route('/logout')
def logout():
    """User logout"""
    session.clear()
    return redirect(url_for('index'))

@app.route('/webmail')
def webmail():
    """Webmail login page"""
    return render_template('webmail_login.html')

@app.route('/webmail-login', methods=['POST'])
def webmail_login():
    """Webmail login handler"""
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()
    
    user = get_user_by_username(username)
    if not user or user['password_hash'] != hash_password(password):
        return render_template('webmail_login.html', error="Invalid credentials"), 401
    
    session['webmail_user_id'] = user['id']
    session['webmail_email'] = user['email']
    
    return redirect(url_for('webmail_inbox'))

@app.route('/webmail/inbox')
def webmail_inbox():
    """Webmail inbox"""
    if 'webmail_user_id' not in session:
        return redirect(url_for('webmail'))
    
    email = session.get('webmail_email', '')
    emails = get_emails_for(email)
    
    return render_template('webmail_inbox.html', 
                          email=email,
                          emails=emails)

@app.route('/webmail/logout')
def webmail_logout():
    """Webmail logout"""
    session.pop('webmail_user_id', None)
    session.pop('webmail_email', None)
    return redirect(url_for('webmail'))

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=8080, debug=False)
